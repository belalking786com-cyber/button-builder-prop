// BUTTON BUILDER PRO — GALAXY VIP V6 MAX
// Single-file Cloudflare Worker.
// Required bindings: BOT_TOKEN (Secret), ADMIN_ID (Variable),
// WEBHOOK_SECRET (Secret), BB_KV (KV Namespace).
// Optional: REQUIRED_CHANNELS (comma-separated Telegram channel IDs),
// CHANNEL_LINKS (comma-separated links), BOT_USERNAME.
// Webhook: https://YOUR-WORKER.workers.dev/?secret=WEBHOOK_SECRET
// Add a Cron Trigger every minute for scheduled posts.
// Bot must be admin in required/source/destination channels as needed.
// Owner (ADMIN_ID) bypasses force-join; all other users must join ALL channels.

const V="6.0.0", P="v6:";
const key=x=>P+x, j=x=>JSON.stringify(x);
const dec=(x,d)=>{try{return x==null?d:JSON.parse(x)}catch{return d}};
const id=x=>String(x??"");
const esc=x=>String(x??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const owner=(e,u)=>id(e.ADMIN_ID)===id(u);
async function get(e,k,d){return dec(await e.BB_KV.get(key(k)),d)}
async function put(e,k,v){return e.BB_KV.put(key(k),j(v))}
async function tg(e,m,b={}){let r=await fetch(`https://api.telegram.org/bot${e.BOT_TOKEN}/${m}`,{method:"POST",headers:{"content-type":"application/json"},body:j(b)});let x=await r.json().catch(()=>({}));if(!x.ok)console.log(m,x.description);return x}
async function send(e,c,t,x={}){return tg(e,"sendMessage",{chat_id:c,text:t,parse_mode:"HTML",disable_web_page_preview:true,...x})}
async function cb(e,q,t="",alert=false){return tg(e,"answerCallbackQuery",{callback_query_id:q.id,text:t,show_alert:alert})}
async function admins(e){return get(e,"admins",{})}
async function isAdmin(e,u){return owner(e,u)||!!(await admins(e))[id(u)]?.active}
async function permit(e,u,p){if(owner(e,u))return true;let a=(await admins(e))[id(u)];return !!a?.active&&(a.permissions||[]).includes(p)}
async function users(e){return get(e,"users",{})}
async function saveUser(e,u,ref){let a=await users(e),k=id(u.id),old=a[k]||{};a[k]={id:u.id,name:u.first_name||"",username:u.username||"",joined:old.joined||Date.now(),seen:Date.now(),blocked:old.blocked||false,referrals:old.referrals||0,referred_by:old.referred_by||null,language:old.language||"en"};if(ref&&ref!==k&&!old.referred_by&&!old.joined){a[k].referred_by=ref;if(a[ref])a[ref].referrals=(a[ref].referrals||0)+1}await put(e,"users",a)}
async function blocked(e,u){return !!(await users(e))[id(u)]?.blocked}
const reqs=e=>(e.REQUIRED_CHANNELS||"").split(",").map(x=>x.trim()).filter(Boolean);
const links=e=>(e.CHANNEL_LINKS||"").split(",").map(x=>x.trim()).filter(Boolean);
async function joined(e,u){for(let c of reqs(e)){let r=await tg(e,"getChatMember",{chat_id:c,user_id:u});if(!r.ok||!["member","administrator","creator"].includes(r.result?.status))return false}return true}
async function gate(e,c,u){if(owner(e,u)||!reqs(e).length||await joined(e,u))return true;let cs=reqs(e),ls=links(e),rows=cs.map((x,i)=>[{text:`JOIN CHANNEL ${i+1}`,url:ls[i]||(x.startsWith("@")?`https://t.me/${x.slice(1)}`:"https://t.me/")}]);rows.push([{text:"✅ CHECK JOIN",callback_data:"joincheck"}]);await send(e,c,"🔒 <b>CHANNEL JOIN REQUIRED</b>\n\nBot استعمال کرنے سے پہلے تمام Required Channels Join کریں، پھر CHECK JOIN دبائیں۔",{reply_markup:{inline_keyboard:rows}});return false}
function keyboard(admin){let a=[[{text:"🧩 Button Builder",callback_data:"page:buttons"},{text:"📝 Post Manager",callback_data:"page:posts"}],[{text:"📅 Scheduler",callback_data:"page:schedule"},{text:"📡 Channels",callback_data:"page:channels"}],[{text:"🔁 Auto Forward",callback_data:"page:forward"},{text:"📊 Analytics",callback_data:"page:analytics"}],[{text:"🎁 Referral",callback_data:"page:referral"},{text:"🎫 Support Tickets",callback_data:"page:tickets"}],[{text:"💾 Backup",callback_data:"page:backup"},{text:"🌐 Language",callback_data:"page:language"}],[{text:"⚙️ Settings",callback_data:"page:settings"},{text:"❓ Help",callback_data:"page:help"}]];if(admin)a.push([{text:"👑 Admin Panel",callback_data:"page:admin"}]);return{inline_keyboard:a}}
async function home(e,c,u){let lang=(await users(e))[id(u)]?.language||"en";return send(e,c,lang==="ur"?"<b>BUTTON BUILDER PRO V6 MAX</b>\nخوش آمدید! کوئی Feature منتخب کریں۔":`<b>BUTTON BUILDER PRO — GALAXY VIP V6 MAX</b>\nWelcome! Select a feature.\nVersion ${V}`,{reply_markup:keyboard(await isAdmin(e,u))})}
async function stat(e,k,n=1){let s=await get(e,"stats",{});s[k]=(s[k]||0)+n;await put(e,"stats",s)}
async function draftAdd(e,u,d){let a=await get(e,`drafts:${u}`,[]);a.unshift(d);await put(e,`drafts:${u}`,a.slice(0,50))}
async function publish(e,u,did){let ds=await get(e,`drafts:${u}`,[]),d=ds.find(x=>x.id===did);if(!d)return{error:"Draft not found"};let cs=await get(e,`channels:${u}`,[]);if(!cs.length)return{error:"No channels. Use /addchannel @username"};let ok=0,fail=0;for(let c of cs){let b={chat_id:c.id,caption:d.text||"",parse_mode:"HTML"},m="sendMessage";if(d.media){m=({photo:"sendPhoto",video:"sendVideo",document:"sendDocument",audio:"sendAudio",voice:"sendVoice",animation:"sendAnimation"})[d.media.type]||"sendMessage";b[d.media.type==="animation"?"animation":d.media.type]=d.media.file_id;if(d.media.type==="voice")delete b.parse_mode; if(d.media.type==="voice")delete b.caption,b.caption=d.text||"";}else b.text=d.text||"(empty post)";if(d.buttons?.length)b.reply_markup={inline_keyboard:d.buttons};let r=await tg(e,m,b);r.ok?ok++:fail++}await stat(e,"published",ok);await stat(e,"failed",fail);return{ok,fail,total:cs.length}}
async function sendDraft(e,c,u,d){let ds=await get(e,`drafts:${u}`,[]),x=ds.find(z=>z.id===d);if(!x)return send(e,c,"Draft not found");return send(e,c,`<b>PREVIEW</b>\n${esc(x.text||"[Media post]")}\nID: <code>${x.id}</code>`,{reply_markup:{inline_keyboard:[[{text:"📤 Publish to channels",callback_data:`pub:${x.id}`}],[{text:"🗑 Delete",callback_data:`del:${x.id}`}]]}})}
async function page(e,c,u,p){let text={
buttons:"<b>BUTTON BUILDER</b>\n/button LABEL | https://example.com\n/clearbuttons\nAdd buttons, then send text/media to save a draft.",
posts:"<b>POST MANAGER</b>\nCreate Post button starts draft mode. Supports text, photo, video, document, audio, voice and animation.\n/drafts",
schedule:"<b>SCHEDULER</b>\n/schedule CHANNEL_ID | YYYY-MM-DD HH:MM | MESSAGE\n/schedules\n/cancelschedule ID\nCron Trigger every minute. Time input is Asia/Karachi.",
channels:"<b>CHANNELS</b>\n/addchannel @channelusername\n/channels\n/removechannel CHANNEL_ID\nBot needs post permission in destinations.",
forward:"<b>AUTO FORWARD</b>\n/forward SOURCE_ID | DESTINATION_ID\n/forwards\n/unforward SOURCE_ID\nBot must receive channel_post updates.",
analytics:"<b>ANALYTICS</b>\n/analytics — users, posts, forwards, failures and referrals.",
referral:"<b>REFERRAL</b>\n/referral — personal invite link and referral count. Set BOT_USERNAME.",
tickets:"<b>SUPPORT TICKETS</b>\n/ticket Your message\n/mytickets\nAdmin: /replyticket TICKET_ID | reply\n/closeticket TICKET_ID",
backup:"<b>BACKUP</b>\n/adminbackup — owner backup text (small backups only).\n/restorebackup — upload JSON backup document (owner only).",
language:"<b>LANGUAGE</b>\n/language en\n/language ur",
settings:"<b>SETTINGS</b>\n/timezone Asia/Karachi\n/maintenance on|off",
help:"<b>HELP</b>\n/start /help /ticket MESSAGE /language en|ur",
admin:"<b>ADMIN PANEL</b>\n/users\n/broadcast MESSAGE\n/block USER_ID\n/unblock USER_ID\n/addadmin USER_ID\n/removeadmin USER_ID\n/maintenance on|off\n/adminbackup"
}[p]||"Unknown page";return send(e,c,text,{reply_markup:{inline_keyboard:[[ {text:"⬅️ Main Menu",callback_data:"home"} ]]}})}
async function ticket(e,u,text){let a=await get(e,"tickets",[]),t={id:"T"+Date.now(),user:u,text,status:"open",at:Date.now(),replies:[]};a.unshift(t);await put(e,"tickets",a);return t}
async function listDrafts(e,c,u){let a=await get(e,`drafts:${u}`,[]);if(!a.length)return send(e,c,"No drafts yet.");return send(e,c,"<b>YOUR DRAFTS</b>",{reply_markup:{inline_keyboard:a.slice(0,15).map(d=>[{text:(d.text||"Media post").slice(0,30)+" · "+d.id.slice(-5),callback_data:"draft:"+d.id}])}})}
async function processMessage(e,m){let u=m.from,uid=u.id,c=m.chat.id,t=(m.text||"").trim();await saveUser(e,u);if(await blocked(e,uid))return send(e,c,"Your access is blocked.");let maint=await get(e,"maintenance",false);if(maint&&!owner(e,uid))return send(e,c,"Bot is under maintenance.");if(t.startsWith("/start")){await saveUser(e,u,t.split(/\s+/)[1]);if(!await gate(e,c,uid))return;await stat(e,"starts");return home(e,c,uid)}if(!await gate(e,c,uid))return;
let state=await get(e,`state:${uid}`,null);
if(state?.mode==="draft"){let media=null;if(m.photo?.length)media={type:"photo",file_id:m.photo.at(-1).file_id};else for(let x of ["video","document","audio","voice","animation"])if(m[x]){media={type:x,file_id:m[x].file_id};break}let d={id:"D"+Date.now(),text:m.caption||t,media,buttons:state.buttons||[],created:Date.now()};await draftAdd(e,uid,d);await put(e,`state:${uid}`,null);return send(e,c,`✅ Draft saved: <code>${d.id}</code>`,{reply_markup:{inline_keyboard:[[{text:"Preview",callback_data:"draft:"+d.id}]]}})}
if(t==="/help")return page(e,c,uid,"help");if(t==="/drafts")return listDrafts(e,c,uid);
if(t==="/channels"){let a=await get(e,`channels:${uid}`,[]);return send(e,c,a.length?a.map(x=>`${esc(x.title)} <code>${x.id}</code>`).join("\n"):"No saved channels.")}
if(t==="/schedules"){let a=await get(e,"schedules",[]);return send(e,c,a.length?a.map(x=>`${x.id} ${new Date(x.at).toLocaleString("en-PK",{timeZone:"Asia/Karachi"})} ${esc(x.text)}`).join("\n"):"No schedules.")}
if(t==="/forwards"){let a=await get(e,"forwards",[]);return send(e,c,a.length?a.map(x=>`${x.source} → ${x.dest}`).join("\n"):"No forward routes.")}
if(t==="/referral"){let me=(await users(e))[id(uid)],link=`https://t.me/${e.BOT_USERNAME||"YOUR_BOT_USERNAME"}?start=${uid}`;return send(e,c,`Your referral link:\n<code>${link}</code>\nReferrals: ${me?.referrals||0}`)}
if(t.startsWith("/ticket ")){let z=await ticket(e,uid,t.slice(8));await send(e,c,`Ticket created: <code>${z.id}</code>`);return send(e,e.ADMIN_ID,`New ticket ${z.id} from ${uid}:\n${esc(z.text)}`)}
if(t==="/mytickets"){let a=(await get(e,"tickets",[])).filter(x=>id(x.user)===id(uid));return send(e,c,a.length?a.map(x=>`${x.id} — ${x.status}`).join("\n"):"No tickets.")}
if(t.startsWith("/language ")){let us=await users(e);if(us[id(uid)])us[id(uid)].language=t.split(/\s+/)[1]==="ur"?"ur":"en";await put(e,"users",us);return send(e,c,"Language updated.")}
if(t.startsWith("/addchannel ")&&await permit(e,uid,"channels")){let target=t.split(/\s+/)[1],r=await tg(e,"getChat",{chat_id:target});if(!r.ok)return send(e,c,"Channel not found. Add bot as admin.");let a=await get(e,`channels:${uid}`,[]);if(!a.some(x=>id(x.id)===id(r.result.id)))a.push({id:r.result.id,title:r.result.title||target});await put(e,`channels:${uid}`,a);return send(e,c,"Channel added: "+esc(r.result.title))}
if(t.startsWith("/removechannel ")&&await permit(e,uid,"channels")){let n=t.split(/\s+/)[1],a=await get(e,`channels:${uid}`,[]);await put(e,`channels:${uid}`,a.filter(x=>id(x.id)!==n));return send(e,c,"Channel removed if found.")}
if(t.startsWith("/button ")){let [label,url]=t.slice(8).split("|").map(x=>x.trim());if(!label||!/^https?:\/\//i.test(url||""))return send(e,c,"Use /button LABEL | https://example.com");let s=await get(e,`state:${uid}`,{mode:"draft",buttons:[]});s.mode="draft";s.buttons=s.buttons||[];s.buttons.push([{text:label,url}]);await put(e,`state:${uid}`,s);return send(e,c,"Button added. Send post text/media.")}
if(t==="/clearbuttons"){let s=await get(e,`state:${uid}`,{mode:"draft"});s.buttons=[];await put(e,`state:${uid}`,s);return send(e,c,"Buttons cleared.")}
if(t.startsWith("/publish ")&&await permit(e,uid,"publish")){let r=await publish(e,uid,t.split(/\s+/)[1]);return send(e,c,r.error||`Published ${r.ok}/${r.total}; failed ${r.fail}.`)}
if(t.startsWith("/schedule ")&&await permit(e,uid,"schedule")){let a=t.slice(10).split("|").map(x=>x.trim());if(a.length<3)return send(e,c,"Use /schedule CHANNEL_ID | YYYY-MM-DD HH:MM | MESSAGE");let dt=new Date(a[1].replace(" ","T")+":00+05:00");if(isNaN(dt))return send(e,c,"Invalid date.");let ss=await get(e,"schedules",[]),s={id:"S"+Date.now(),channel:a[0],at:dt.getTime(),text:a.slice(2).join(" | "),owner:uid};ss.push(s);await put(e,"schedules",ss);return send(e,c,"Scheduled "+s.id)}
if(t.startsWith("/cancelschedule ")&&await permit(e,uid,"schedule")){let n=t.split(/\s+/)[1],a=await get(e,"schedules",[]);await put(e,"schedules",a.filter(x=>x.id!==n));return send(e,c,"Schedule cancelled if found.")}
if(t.startsWith("/forward ")&&await permit(e,uid,"forward")){let [s,d]=t.slice(9).split("|").map(x=>x.trim());if(!s||!d)return send(e,c,"Use /forward SOURCE_ID | DESTINATION_ID");let a=await get(e,"forwards",[]);a.push({source:s,dest:d,active:true});await put(e,"forwards",a);return send(e,c,"Forward route saved.")}
if(t.startsWith("/unforward ")&&await permit(e,uid,"forward")){let n=t.split(/\s+/)[1],a=await get(e,"forwards",[]);await put(e,"forwards",a.filter(x=>x.source!==n));return send(e,c,"Forward route removed.")}
if(t.startsWith("/replyticket ")&&await isAdmin(e,uid)){let [n,...r]=t.slice(13).split("|"),reply=r.join("|").trim(),a=await get(e,"tickets",[]),z=a.find(x=>x.id===n.trim());if(!z)return send(e,c,"Ticket not found.");z.replies.push({text:reply,at:Date.now()});await put(e,"tickets",a);await send(e,z.user,`Support reply ${z.id}:\n${esc(reply)}`);return send(e,c,"Reply sent.")}
if(t.startsWith("/closeticket ")&&await isAdmin(e,uid)){let n=t.split(/\s+/)[1],a=await get(e,"tickets",[]),z=a.find(x=>x.id===n);if(z)z.status="closed";await put(e,"tickets",a);return send(e,c,"Ticket closed if found.")}
if(t==="/analytics"&&await permit(e,uid,"analytics")){let s=await get(e,"stats",{}),us=await users(e);return send(e,c,`<b>ANALYTICS</b>\nUsers: ${Object.keys(us).length}\nStarts: ${s.starts||0}\nPublished: ${s.published||0}\nFailed: ${s.failed||0}\nForwarded: ${s.forwarded||0}\nScheduled: ${s.scheduled||0}`)}
if(t==="/users"&&await permit(e,uid,"users")){let us=await users(e);return send(e,c,"Users: "+Object.keys(us).length)}
if(t.startsWith("/block ")&&await permit(e,uid,"users")){let n=t.split(/\s+/)[1],us=await users(e);if(us[n])us[n].blocked=true;await put(e,"users",us);return send(e,c,"Blocked if user exists.")}
if(t.startsWith("/unblock ")&&await permit(e,uid,"users")){let n=t.split(/\s+/)[1],us=await users(e);if(us[n])us[n].blocked=false;await put(e,"users",us);return send(e,c,"Unblocked if user exists.")}
if(t.startsWith("/broadcast ")&&await permit(e,uid,"broadcast")){let us=await users(e),ok=0,fail=0;for(let z of Object.values(us))if(!z.blocked){let r=await send(e,z.id,t.slice(11));r.ok?ok++:fail++}return send(e,c,`Broadcast sent ${ok}, failed ${fail}.`)}
if(t.startsWith("/addadmin ")&&owner(e,uid)){let n=t.split(/\s+/)[1],a=await admins(e);a[n]={active:true,permissions:["channels","publish","schedule","forward","users","broadcast","analytics","tickets"]};await put(e,"admins",a);return send(e,c,"Sub-admin added.")}
if(t.startsWith("/removeadmin ")&&owner(e,uid)){let n=t.split(/\s+/)[1],a=await admins(e);delete a[n];await put(e,"admins",a);return send(e,c,"Sub-admin removed.")}
if(t.startsWith("/maintenance ")&&owner(e,uid)){let on=t.split(/\s+/)[1]==="on";await put(e,"maintenance",on);return send(e,c,"Maintenance "+(on?"ON":"OFF"))}
if(t==="/adminbackup"&&owner(e,uid)){let names=["users","channels","admins","schedules","forwards","tickets","stats"],data={version:V,data:{}};for(let n of names)data.data[n]=await get(e,n,{});let s=JSON.stringify(data);if(s.length>3800)return send(e,c,"Backup too large for Telegram text. Use KV export from Cloudflare dashboard.");return send(e,c,"<pre>"+esc(s)+"</pre>")}
if(m.document&&owner(e,uid)){let f=await tg(e,"getFile",{file_id:m.document.file_id});if(!f.ok)return send(e,c,"Could not read file.");let r=await fetch(`https://api.telegram.org/file/bot${e.BOT_TOKEN}/${f.result.file_path}`),d=await r.json().catch(()=>null);if(!d?.data)return send(e,c,"Invalid JSON backup.");for(let [n,v] of Object.entries(d.data))await put(e,n,v);return send(e,c,"Backup restored.")}
return send(e,c,"Choose a feature from Main Menu or type /help.")}
async function callback(e,q){let u=q.from.id,c=q.message.chat.id,d=q.data||"";if(await blocked(e,u))return cb(e,q,"Access blocked",true);if(d==="joincheck"){if(await joined(e,u)){await cb(e,q,"Membership verified");return home(e,c,u)}return cb(e,q,"Join every required channel first.",true)}if(!await gate(e,c,u))return cb(e,q,"Join required channels first.",true);if(d==="home"){await cb(e,q);return home(e,c,u)}if(d.startsWith("page:")){let p=d.slice(5);if(p==="admin"&&!await isAdmin(e,u))return cb(e,q,"Not allowed",true);await cb(e,q);return page(e,c,u,p)}if(d==="create"){await put(e,`state:${u}`,{mode:"draft",buttons:[]});await cb(e,q);return send(e,c,"Send post text or media now.")}
if(d.startsWith("draft:")){await cb(e,q);return sendDraft(e,c,u,d.slice(6))}
if(d.startsWith("pub:")){if(!await permit(e,u,"publish"))return cb(e,q,"No publish permission",true);let r=await publish(e,u,d.slice(4));return cb(e,q,r.error||`Published ${r.ok}/${r.total}; failed ${r.fail}`,true)}
if(d.startsWith("del:")){let a=await get(e,`drafts:${u}`,[]);await put(e,`drafts:${u}`,a.filter(x=>x.id!==d.slice(4)));return cb(e,q,"Draft deleted")}
return cb(e,q)}
async function channelPost(e,m){let a=await get(e,"forwards",[]);for(let f of a)if(f.active&&id(f.source)===id(m.chat.id)){let r=await tg(e,"copyMessage",{chat_id:f.dest,from_chat_id:m.chat.id,message_id:m.message_id});await stat(e,r.ok?"forwarded":"failed")}}
async function cron(e){let a=await get(e,"schedules",[]),keep=[];for(let s of a){if(s.at>Date.now()){keep.push(s);continue}let r=await send(e,s.channel,s.text);if(r.ok)await stat(e,"scheduled");else keep.push({...s,at:Date.now()+300000})}await put(e,"schedules",keep)}
export default {
 async fetch(request,env){try{if(!env.BOT_TOKEN||!env.ADMIN_ID||!env.WEBHOOK_SECRET||!env.BB_KV)return new Response("Missing BOT_TOKEN, ADMIN_ID, WEBHOOK_SECRET or BB_KV",{status:500});let url=new URL(request.url);if(url.searchParams.get("secret")!==env.WEBHOOK_SECRET)return new Response("Forbidden",{status:403});if(request.method==="GET")return new Response("BUTTON BUILDER PRO GALAXY VIP V"+V+" ONLINE");if(request.method!=="POST")return new Response("Method Not Allowed",{status:405});let u=await request.json();if(u.message)await processMessage(env,u.message);else if(u.callback_query)await callback(env,u.callback_query);else if(u.channel_post)await channelPost(env,u.channel_post);return new Response("OK")}catch(err){console.log(err);return new Response("Internal Error",{status:500})}},
 async scheduled(event,env,ctx){ctx.waitUntil(cron(env))}
};
